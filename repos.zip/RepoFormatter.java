import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RepoFormatter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String pass = args[0].trim();
		int mode = Integer.parseInt(args[1].trim());

		FileWriter writer = null;
		try {
		Scanner in = new Scanner(new FileInputStream(new File(
					"repos.txt").getAbsolutePath()));
			String line = "";
			String tLine = "";
			List<String> resList = new ArrayList<String>();
			while (in.hasNext()) {
				tLine = in.nextLine().trim();
				if (mode == 1) {
					line = tLine.split(",")[2];
					String partline = line.split("@")[0] + ":" + pass + "@"
							+ line.split("@")[1];
					resList.add(tLine.split(",")[0] + "," + tLine.split(",")[1]
							+ "," + partline);
				}

				if (mode == 0) {
					line = tLine.split(",")[2];
					String httpSplit = line.split(":")[2];
					line = line.split(":")[0] + ":" + line.split(":")[1] + "@"
							+ (httpSplit.split("@")[1]);
					resList.add(tLine.split(",")[0] + "," + tLine.split(",")[1]
							+ "," + line);
				}

			}
			writer = new FileWriter(
					new File("repos.txt").getAbsolutePath());

			for (String val : resList) {

				writer.write(val + "\n");

			}
			writer.close();

		} catch (FileNotFoundException fe) {
			System.out.println("repos.txt not found");
		}

		catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}
