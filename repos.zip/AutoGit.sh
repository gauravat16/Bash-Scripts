#!/bin/bash
#Author Gaurav Sharma
echo -e "Welcome to AutoGit by Gaurav Sharma\nAutoGit makes using GIT relatively easy"
drive=$(pwd | cut -d'/' -f2)
export JAVA_HOME="$drive:/Tools_For_Git/jdk6"
export PATH="$drive:/Tools_For_Git/jdk6/bin:$PATH"

pathToTools="$PWD"
repoFile="$PWD/repos.txt"
username=$(whoami | cut -d'+' -f2)
echo -n "Enter your Stash Password>"
read -s pass
java RepoFormatter $pass 1


mkdir c:/Users/$username/git_$username
cd c:/Users/$username/git_$username
while read -r line || [[ -n "$line" ]];do
	repoName=$(echo "$line" | cut -d',' -f1)
	branch=$(echo "$line" | cut -d',' -f2)
	url=$(echo "$line" | cut -d',' -f3)
	mkdir c:/Users/$username/git_$username/$repoName
	cd c:/Users/$username/git_$username/$repoName
	git init
	git remote rm origin
	git remote add -t $branch -f origin $url
	git checkout $branch
	cd c:/Users/$username

done <$repoFile
cd $pathToTools
java RepoFormatter $pass 0

#cp $PWD/.project c:/Users/$username/git_$username/POS_Device

cd c:/Users/$username/git_$username/master
./gradlew cleanEclipse eclipse